import React, { useState, useEffect } from 'react';
import StoreFront from './components/StoreFront';
import DashboardLayout from './components/Dashboard/DashboardLayout';
import AdminLoginModal from './components/AdminLoginModal';
import { Store, LayoutDashboard, Lock, ShieldCheck } from 'lucide-react';

export default function App() {
  const [storeSlug, setStoreSlug] = useState<string>('achadinhos-da-maria');
  const [viewMode, setViewMode] = useState<'store' | 'dashboard'>('store');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('planiloja_admin_session') || sessionStorage.getItem('planiloja_admin_session');
      if (stored) {
        const parsed = JSON.parse(stored);
        return Boolean(parsed?.authenticated);
      }
    } catch {
      return false;
    }
    return false;
  });
  const [loginModalOpen, setLoginModalOpen] = useState<boolean>(false);

  // Handle URL mode param (e.g. ?mode=dashboard)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const modeParam = params.get('mode');
    const storeParam = params.get('loja') || params.get('store');

    if (storeParam) {
      setStoreSlug(storeParam);
    }

    if (modeParam === 'dashboard' || modeParam === 'admin') {
      if (isAdminLoggedIn) {
        setViewMode('dashboard');
      } else {
        setViewMode('store');
        setLoginModalOpen(true);
      }
    }
  }, [isAdminLoggedIn]);

  function handleRequestDashboard() {
    if (isAdminLoggedIn) {
      setViewMode('dashboard');
      const url = new URL(window.location.href);
      url.searchParams.set('mode', 'dashboard');
      window.history.replaceState({}, '', url.toString());
    } else {
      setLoginModalOpen(true);
    }
  }

  function handleLoginSuccess() {
    setIsAdminLoggedIn(true);
    setLoginModalOpen(false);
    setViewMode('dashboard');
    const url = new URL(window.location.href);
    url.searchParams.set('mode', 'dashboard');
    window.history.replaceState({}, '', url.toString());
  }

  function handleLogout() {
    try {
      localStorage.removeItem('planiloja_admin_session');
      sessionStorage.removeItem('planiloja_admin_session');
    } catch (err) {
      console.error('Error clearing session:', err);
    }
    setIsAdminLoggedIn(false);
    setViewMode('store');
    const url = new URL(window.location.href);
    url.searchParams.delete('mode');
    window.history.replaceState({}, '', url.toString());
  }

  function handleSwitchToStore() {
    setViewMode('store');
    const url = new URL(window.location.href);
    url.searchParams.delete('mode');
    window.history.replaceState({}, '', url.toString());
  }

  return (
    <div className="min-h-screen relative font-['DM_Sans',sans-serif]">
      {/* Floating Mode Switcher Bar - ONLY visible when Admin is logged in */}
      {isAdminLoggedIn && (
        <div className="fixed top-2 right-2 sm:right-6 z-50 flex items-center gap-1 bg-neutral-900/95 text-white p-1 rounded-full shadow-2xl backdrop-blur-md border border-neutral-700/80 transition text-xs font-semibold animate-in fade-in">
          <button
            onClick={handleSwitchToStore}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition ${
              viewMode === 'store'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-300 hover:text-white'
            }`}
            title="Ver a vitrine pública de ofertas"
          >
            <Store className="w-3.5 h-3.5" />
            <span>Vitrine</span>
          </button>

          <button
            id="btn-admin-access"
            onClick={handleRequestDashboard}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition ${
              viewMode === 'dashboard'
                ? 'bg-white text-neutral-900 shadow-xs'
                : 'text-neutral-300 hover:text-white'
            }`}
            title="Painel Administrativo"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Painel</span>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-full text-rose-300 hover:text-rose-200 hover:bg-rose-950/60 transition"
            title="Encerrar sessão de administrador"
          >
            <Lock className="w-3 h-3" />
            <span className="hidden sm:inline">Sair</span>
          </button>
        </div>
      )}

      {/* Render Active View */}
      {viewMode === 'store' ? (
        <StoreFront
          storeSlug={storeSlug}
          onOpenDashboard={handleRequestDashboard}
        />
      ) : (
        <DashboardLayout
          currentStoreSlug={storeSlug}
          onSelectStoreSlug={(slug) => setStoreSlug(slug)}
          onOpenStoreFront={handleSwitchToStore}
          onLogout={handleLogout}
        />
      )}

      {/* Admin Login Popup Modal */}
      <AdminLoginModal
        isOpen={loginModalOpen}
        storeSlug={storeSlug}
        onSuccess={handleLoginSuccess}
        onCancel={() => setLoginModalOpen(false)}
      />
    </div>
  );
}

