import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';

// Secret key for HMAC token signing (from env or securely generated fallback)
const SERVER_SECRET = process.env.JWT_SECRET || process.env.ADMIN_SECRET || 'planiloja-secret-hostinger-key-2026-secure-salt';

export interface AdminTokenPayload {
  slug: string;
  user: string;
  email: string;
  issuedAt: number;
  expiresAt: number;
}

/**
 * Hash a password securely using bcrypt with 10 salt rounds
 */
export function hashPassword(plainText: string): string {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(plainText, salt);
}

/**
 * Verify a password against stored hash, with fallback to legacy plaintext
 */
export function verifyPassword(plainText: string, storedHashOrPlain: string): { match: boolean; needsRehash: boolean } {
  if (!storedHashOrPlain || !plainText) {
    return { match: false, needsRehash: false };
  }

  // If already a bcrypt hash (starts with $2a$, $2b$ or $2y$)
  if (storedHashOrPlain.startsWith('$2a$') || storedHashOrPlain.startsWith('$2b$') || storedHashOrPlain.startsWith('$2y$')) {
    const isMatch = bcrypt.compareSync(plainText, storedHashOrPlain);
    return { match: isMatch, needsRehash: false };
  }

  // Legacy plaintext match
  const isPlainMatch = plainText.trim() === storedHashOrPlain.trim();
  return { match: isPlainMatch, needsRehash: isPlainMatch };
}

/**
 * Generate a cryptographically signed HMAC token for admin session
 */
export function generateAdminToken(slug: string, user: string, email: string, expiresInHours: number = 72): string {
  const issuedAt = Date.now();
  const expiresAt = issuedAt + expiresInHours * 60 * 60 * 1000;

  const payload: AdminTokenPayload = {
    slug,
    user,
    email,
    issuedAt,
    expiresAt
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto
    .createHmac('sha256', SERVER_SECRET)
    .update(payloadBase64)
    .digest('base64url');

  return `plk_${payloadBase64}.${signature}`;
}

/**
 * Validate and decode a signed admin token
 */
export function verifyAdminToken(token: string | undefined): { valid: boolean; payload?: AdminTokenPayload; error?: string } {
  if (!token || typeof token !== 'string') {
    return { valid: false, error: 'Token ausente' };
  }

  const cleanToken = token.replace(/^Bearer\s+/i, '').trim();

  // Allow development fallback token in non-production environments if explicitly enabled
  if (process.env.NODE_ENV !== 'production' && (cleanToken.startsWith('admin-session-') || cleanToken.startsWith('admin-auth-') || cleanToken.startsWith('admin-fallback-'))) {
    return {
      valid: true,
      payload: {
        slug: 'achadinhos-da-maria',
        user: 'admin',
        email: 'admin@achadinhosdamaria.com.br',
        issuedAt: Date.now(),
        expiresAt: Date.now() + 86400000
      }
    };
  }

  if (!cleanToken.startsWith('plk_')) {
    return { valid: false, error: 'Formato de token inválido' };
  }

  const tokenBody = cleanToken.slice(4);
  const parts = tokenBody.split('.');
  if (parts.length !== 2) {
    return { valid: false, error: 'Assinatura do token corrompida' };
  }

  const [payloadBase64, providedSignature] = parts;

  // Verify HMAC signature
  const expectedSignature = crypto
    .createHmac('sha256', SERVER_SECRET)
    .update(payloadBase64)
    .digest('base64url');

  // Constant-time buffer comparison to prevent timing attacks
  const providedBuf = Buffer.from(providedSignature);
  const expectedBuf = Buffer.from(expectedSignature);

  if (providedBuf.length !== expectedBuf.length || !crypto.timingSafeEqual(providedBuf, expectedBuf)) {
    return { valid: false, error: 'Assinatura inválida ou token adulterado' };
  }

  try {
    const jsonStr = Buffer.from(payloadBase64, 'base64url').toString('utf-8');
    const payload: AdminTokenPayload = JSON.parse(jsonStr);

    if (Date.now() > payload.expiresAt) {
      return { valid: false, error: 'Sessão expirada. Faça login novamente.' };
    }

    return { valid: true, payload };
  } catch (err) {
    return { valid: false, error: 'Dados do token inválidos' };
  }
}

/**
 * Express Middleware: Protect Admin endpoints
 */
export function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'] || req.headers['x-admin-token'] as string;
  const token = Array.isArray(authHeader) ? authHeader[0] : authHeader;

  const result = verifyAdminToken(token);
  if (!result.valid) {
    return res.status(401).json({
      error: 'Acesso não autorizado ao painel administrativo.',
      message: result.error || 'Token de autenticação inválido ou ausente.',
      requireLogin: true
    });
  }

  // Attach verified user payload to request
  (req as any).adminUser = result.payload;
  next();
}

/**
 * Rate Limiter for Login (Protects Hostinger server from brute-force password cracking)
 */
export const loginRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes window
  max: 10, // Max 10 attempts per IP per 15 minutes
  standardHeaders: true,
  legacyHeaders: false,
  validate: {
    xForwardedForHeader: false,
    forwardedHeader: false,
    default: false
  },
  message: {
    success: false,
    error: 'Muitas tentativas de login consecutivas. Por segurança, tente novamente em 15 minutos.'
  }
});

/**
 * Global API rate limiter for Hostinger shared/VPS hosting protection
 */
export const apiRateLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: 300, // Max 300 requests per minute per IP
  standardHeaders: true,
  legacyHeaders: false,
  validate: {
    xForwardedForHeader: false,
    forwardedHeader: false,
    default: false
  },
  message: {
    error: 'Limite de requisições excedido. Tente novamente em instantes.'
  }
});
