import * as cheerio from 'cheerio';
import { PriceCheckResult, PriceMarkupType, PriceMonitorSettings, OutOfStockAction } from '../types';

// Helper to normalize and parse Brazilian currency strings (e.g. "R$ 1.299,99", "1299.99", "R$ 49,90")
export function parsePriceString(text: string | null | undefined): number | null {
  if (!text || typeof text !== 'string') return null;
  
  // Clean whitespace and common currency terms
  let clean = text.trim();
  
  // Look for price patterns like "R$ 1.299,90", "1.299,90", "129.90", "49,90"
  // Match standard Brazilian currency formats
  const match = clean.match(/(?:R\$|\$|BRL)?\s*([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]{1,2})|[0-9]+(?:\.[0-9]{2})?|[0-9]+,[0-9]{2})/i);
  
  if (match && match[1]) {
    let numStr = match[1];
    if (numStr.includes(',') && numStr.includes('.')) {
      // 1.299,90 -> remove dots, replace comma with dot
      numStr = numStr.replace(/\./g, '').replace(',', '.');
    } else if (numStr.includes(',')) {
      // 129,90 -> replace comma with dot
      numStr = numStr.replace(',', '.');
    }
    const val = parseFloat(numStr);
    return isNaN(val) || val <= 0 ? null : Math.round(val * 100) / 100;
  }
  
  // Fallback: extract digits
  const fallbackMatch = clean.replace(/[^0-9,.]/g, '');
  if (fallbackMatch) {
    let numStr = fallbackMatch;
    if (numStr.includes(',') && numStr.includes('.')) {
      numStr = numStr.replace(/\./g, '').replace(',', '.');
    } else if (numStr.includes(',')) {
      numStr = numStr.replace(',', '.');
    }
    const val = parseFloat(numStr);
    return isNaN(val) || val <= 0 ? null : Math.round(val * 100) / 100;
  }

  return null;
}

export function detectPlatformFromUrl(url: string): string {
  const lower = (url || '').toLowerCase();
  if (lower.includes('amazon.') || lower.includes('amzn.to')) return 'Amazon';
  if (lower.includes('shopee.') || lower.includes('shp.ee')) return 'Shopee';
  if (lower.includes('aliexpress.') || lower.includes('alicdn') || lower.includes('a.aliexpress.com')) return 'AliExpress';
  if (lower.includes('magazineluiza.') || lower.includes('magazinevoce.') || lower.includes('magalu.')) return 'Magalu';
  if (lower.includes('hotmart.') || lower.includes('go.hotmart.com') || lower.includes('pay.hotmart.com')) return 'Hotmart';
  if (lower.includes('kiwify.') || lower.includes('pay.kiwify.com.br')) return 'Kiwify';
  if (lower.includes('mercadolivre.') || lower.includes('mercadolivre.com.br') || lower.includes('mlb.')) return 'Mercado Livre';
  if (lower.includes('braip.') || lower.includes('ev.braip.com')) return 'Braip';
  if (lower.includes('eduzz.') || lower.includes('sun.eduzz.com')) return 'Eduzz';
  if (lower.includes('shein.')) return 'Shein';
  if (lower.includes('tiktok.com')) return 'TikTok Shop';
  return 'Outro Fornecedor';
}

export function calculateMarkupPrice(
  supplierPrice: number | null,
  markupType: PriceMarkupType = 'direct',
  markupValue: number = 0
): number | null {
  if (supplierPrice === null || supplierPrice <= 0) return null;
  
  if (markupType === 'percentage' && markupValue > 0) {
    const calculated = supplierPrice * (1 + markupValue / 100);
    return Math.round(calculated * 100) / 100;
  }
  
  if (markupType === 'fixed' && markupValue > 0) {
    const calculated = supplierPrice + markupValue;
    return Math.round(calculated * 100) / 100;
  }
  
  return supplierPrice;
}

export async function fetchSupplierData(
  targetUrl: string,
  options?: { timeoutMs?: number }
): Promise<PriceCheckResult> {
  const checkedAt = new Date().toISOString();
  const platform = detectPlatformFromUrl(targetUrl);
  
  const defaultResult: PriceCheckResult = {
    url: targetUrl,
    platform,
    supplierPrice: null,
    supplierPromo: null,
    calculatedPrice: null,
    calculatedPromo: null,
    inStock: true,
    currency: 'BRL',
    diffPercent: 0,
    status: 'unchanged',
    checkedAt
  };

  if (!targetUrl || typeof targetUrl !== 'string' || (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://'))) {
    return {
      ...defaultResult,
      status: 'error',
      message: 'URL inválida. Forneça uma URL completa começando com http:// ou https://'
    };
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), options?.timeoutMs || 10000);

    const response = await fetch(targetUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
        'Referer': 'https://www.google.com/'
      },
      redirect: 'follow'
    });

    clearTimeout(timeout);

    if (!response.ok) {
      return {
        ...defaultResult,
        status: response.status === 404 ? 'not_found' : 'error',
        message: `Fornecedor respondeu com status HTTP ${response.status} (${response.statusText})`,
        inStock: false
      };
    }

    const html = await response.text();
    const $ = cheerio.load(html);

    let extractedTitle: string | undefined = undefined;
    let extractedImage: string | undefined = undefined;
    let extractedPrice: number | null = null;
    let extractedPromo: number | null = null;
    let isOutOfStock = false;
    let detectedCurrency = 'BRL';

    // 1. Check title
    extractedTitle = $('meta[property="og:title"]').attr('content') ||
                     $('meta[name="twitter:title"]').attr('content') ||
                     $('h1').first().text().trim() ||
                     $('title').text().trim();

    // Clean title
    if (extractedTitle) {
      extractedTitle = extractedTitle.replace(/\s+/g, ' ').trim();
    }

    // 2. Check image
    extractedImage = $('meta[property="og:image"]').attr('content') ||
                     $('meta[name="twitter:image"]').attr('content') ||
                     $('link[rel="image_src"]').attr('href');

    // 3. Out of stock detection text in page
    const bodyText = $('body').text().toLowerCase();
    if (
      bodyText.includes('produto esgotado') ||
      bodyText.includes('produto indisponível') ||
      bodyText.includes('avise-me quando chegar') ||
      bodyText.includes('fora de estoque') ||
      bodyText.includes('temporariamente sem estoque') ||
      bodyText.includes('não encontramos o produto') ||
      bodyText.includes('este anúncio foi finalizado')
    ) {
      isOutOfStock = true;
    }

    // 4. Try parsing JSON-LD structured data (Schema.org / Product)
    $('script[type="application/ld+json"]').each((_, el) => {
      try {
        const text = $(el).html();
        if (!text) return;
        const data = JSON.parse(text);
        const parseOffer = (offer: any) => {
          if (!offer) return;
          const p = parsePriceString(String(offer.price || offer.lowPrice || offer.highPrice || ''));
          if (p && !extractedPrice) {
            extractedPrice = p;
          }
          if (offer.priceCurrency) {
            detectedCurrency = String(offer.priceCurrency).toUpperCase();
          }
          if (offer.availability && typeof offer.availability === 'string') {
            if (offer.availability.includes('OutOfStock') || offer.availability.includes('Discontinued')) {
              isOutOfStock = true;
            } else if (offer.availability.includes('InStock')) {
              isOutOfStock = false;
            }
          }
        };

        if (data['@type'] === 'Product' || data['@type']?.includes?.('Product')) {
          if (data.name && !extractedTitle) extractedTitle = data.name;
          if (data.image) {
            extractedImage = Array.isArray(data.image) ? data.image[0] : (typeof data.image === 'string' ? data.image : data.image?.url);
          }
          if (data.offers) {
            if (Array.isArray(data.offers)) {
              data.offers.forEach(parseOffer);
            } else {
              parseOffer(data.offers);
            }
          }
        } else if (Array.isArray(data)) {
          data.forEach(item => {
            if (item['@type'] === 'Product') {
              if (item.offers) {
                if (Array.isArray(item.offers)) item.offers.forEach(parseOffer);
                else parseOffer(item.offers);
              }
            }
          });
        }
      } catch (e) {
        // ignore malformed JSON-LD
      }
    });

    // 5. Try OpenGraph and Meta tags
    if (!extractedPrice) {
      const ogPrice = $('meta[property="product:price:amount"]').attr('content') ||
                      $('meta[property="og:price:amount"]').attr('content') ||
                      $('meta[name="twitter:data1"]').attr('content');
      if (ogPrice) {
        extractedPrice = parsePriceString(ogPrice);
      }
    }

    // 6. Platform-Specific Selector Fallbacks
    if (platform === 'Amazon') {
      // Amazon Price Selectors
      const priceWhole = $('.a-price .a-price-whole').first().text().trim();
      const priceFraction = $('.a-price .a-price-fraction').first().text().trim();
      if (priceWhole) {
        const full = priceWhole + (priceFraction ? ',' + priceFraction : '');
        const p = parsePriceString(full);
        if (p) extractedPrice = p;
      }
      
      const offscreenPrice = $('.a-price .a-offscreen').first().text().trim();
      if (offscreenPrice && !extractedPrice) {
        extractedPrice = parsePriceString(offscreenPrice);
      }

      // Strike price / list price
      const strikePrice = $('.basisPrice .a-offscreen, .a-text-price .a-offscreen').first().text().trim();
      if (strikePrice) {
        const promo = parsePriceString(strikePrice);
        if (promo && extractedPrice && promo > extractedPrice) {
          extractedPromo = extractedPrice;
          extractedPrice = promo;
        }
      }

      if ($('#availability .a-color-state').text().toLowerCase().includes('indisponível') ||
          $('#availability').text().toLowerCase().includes('não temos previsão')) {
        isOutOfStock = true;
      }
    } else if (platform === 'Magalu') {
      // Magalu Price Selectors
      const magaluPrice = $('[data-testid="price-value"], .price-template__text, [data-testid="price-default"]').text().trim();
      if (magaluPrice) {
        const p = parsePriceString(magaluPrice);
        if (p) extractedPrice = p;
      }
      const magaluOriginal = $('[data-testid="price-original"]').text().trim();
      if (magaluOriginal) {
        const orig = parsePriceString(magaluOriginal);
        if (orig && extractedPrice && orig > extractedPrice) {
          extractedPromo = extractedPrice;
          extractedPrice = orig;
        }
      }
    } else if (platform === 'Shopee') {
      // Shopee Specific Regex & Selectors in Script
      const priceMatch = html.match(/"price":\s*([0-9]+)/);
      if (priceMatch && priceMatch[1]) {
        // Shopee prices in raw JSON are often in micro-units (x100000)
        let rawNum = parseInt(priceMatch[1], 10);
        if (rawNum > 10000) {
          rawNum = rawNum / 100000;
        }
        if (rawNum > 0 && !extractedPrice) {
          extractedPrice = Math.round(rawNum * 100) / 100;
        }
      }
      const shopeeElPrice = $('._2v0HG1, .pmmxKx, .shopee-price-detail').text().trim();
      if (shopeeElPrice && !extractedPrice) {
        extractedPrice = parsePriceString(shopeeElPrice);
      }
    } else if (platform === 'AliExpress') {
      // AliExpress
      const aliMatch = html.match(/"formattedAmount":\s*"([^"]+)"/) || html.match(/"actSkuMultiCurrencyDisplayPrice":\s*"([^"]+)"/);
      if (aliMatch && aliMatch[1]) {
        extractedPrice = parsePriceString(aliMatch[1]);
      }
      const aliEl = $('.product-price-value, .snow-price, .uniform-banner-box-price').text().trim();
      if (aliEl && !extractedPrice) {
        extractedPrice = parsePriceString(aliEl);
      }
    } else if (platform === 'Hotmart' || platform === 'Kiwify' || platform === 'Braip' || platform === 'Eduzz') {
      // Digital Product Platforms (Hotmart / Kiwify / Braip / Eduzz)
      // Look for checkout price elements or standard currency badges
      const checkoutPrice = $('[data-test-id="product-price"], .checkout-price, .product-price, .hotmart-price, .price-container, .payment-total').text().trim();
      if (checkoutPrice) {
        const p = parsePriceString(checkoutPrice);
        if (p) extractedPrice = p;
      }
      
      // Look for regex in script tags (many checkouts inject initial data into JS variables)
      const jsPriceMatch = html.match(/(?:productPrice|checkoutPrice|offerPrice|totalAmount|priceFormatted|amount)":?\s*["']?([0-9.,]+)["']?/i) ||
                           html.match(/R\$\s*([0-9]{1,3}(?:\.[0-9]{3})*,[0-9]{2})/);
      if (jsPriceMatch && jsPriceMatch[1] && !extractedPrice) {
        extractedPrice = parsePriceString(jsPriceMatch[1]);
      }
    }

    // 7. General Regex scan if still no price found
    if (!extractedPrice) {
      // Find visible price patterns
      const generalMatches = html.match(/R\$\s*([0-9]{1,3}(?:\.[0-9]{3})*,[0-9]{2})/g);
      if (generalMatches && generalMatches.length > 0) {
        // Take the most frequently occurring or first reasonable price
        const prices = generalMatches.map(m => parsePriceString(m)).filter((p): p is number => p !== null && p > 0);
        if (prices.length > 0) {
          extractedPrice = prices[0];
        }
      }
    }

    // If still nothing found
    if (!extractedPrice && !isOutOfStock) {
      return {
        ...defaultResult,
        detectedName: extractedTitle,
        detectedImage: extractedImage,
        status: 'error',
        message: 'Não foi possível detectar o preço nesta página automaticamente. O site pode ter proteção antibot ou o layout mudou.',
        inStock: true
      };
    }

    return {
      ...defaultResult,
      detectedName: extractedTitle,
      detectedImage: extractedImage,
      supplierPrice: extractedPrice,
      supplierPromo: extractedPromo,
      inStock: !isOutOfStock,
      status: isOutOfStock ? 'out_of_stock' : 'unchanged',
      currency: detectedCurrency
    };

  } catch (err: any) {
    return {
      ...defaultResult,
      status: 'error',
      message: `Erro ao consultar fornecedor: ${err?.message || 'Falha de conexão ou tempo limite excedido'}`
    };
  }
}
