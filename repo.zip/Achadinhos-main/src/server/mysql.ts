import fs from 'fs';
import path from 'path';
import mysql from 'mysql2/promise';
import { StoreConfig, Product, Category, Platform, ClickRecord, StoreUser } from '../types';

export interface MySqlConfig {
  host?: string;
  port?: number;
  user?: string;
  password?: string;
  database?: string;
  ssl?: boolean;
}

const CONFIG_FILE = path.join(process.cwd(), 'data', 'db_config.json');

class MySqlManager {
  private pool: mysql.Pool | null = null;
  private isConnected: boolean = false;
  private connectionError: string | null = null;
  private activeConfig: MySqlConfig | null = null;

  public isReady(): boolean {
    return this.isConnected && this.pool !== null;
  }

  public isLive(): boolean {
    return this.isConnected && this.pool !== null;
  }

  public getStatus() {
    return {
      connected: this.isConnected,
      driver: this.isConnected ? 'Hostinger MySQL / MariaDB (Ativo)' : 'Armazenamento JSON Local (Modo Fallback)',
      error: this.connectionError,
      host: this.activeConfig?.host || process.env.DB_HOST || 'Local / Não configurado',
      database: this.activeConfig?.database || process.env.DB_NAME || 'store_data.json',
      user: this.activeConfig?.user || process.env.DB_USER || 'Nenhum',
      port: this.activeConfig?.port || process.env.DB_PORT || 3306
    };
  }

  public async init(customConfig?: MySqlConfig): Promise<boolean> {
    let config: MySqlConfig = customConfig || {};

    // 1. Check DATABASE_URL or MYSQL_URL
    const dbUrl = process.env.DATABASE_URL || process.env.MYSQL_URL;
    if (dbUrl && (!config.host || !config.database)) {
      try {
        const parsed = new URL(dbUrl);
        if (parsed.hostname) config.host = parsed.hostname;
        if (parsed.port) config.port = Number(parsed.port);
        if (parsed.username) config.user = decodeURIComponent(parsed.username);
        if (parsed.password) config.password = decodeURIComponent(parsed.password);
        if (parsed.pathname && parsed.pathname.length > 1) {
          config.database = parsed.pathname.substring(1);
        }
      } catch (e) {
        console.warn('[Hostinger MySQL] Aviso ao parsear DATABASE_URL:', e);
      }
    }

    // 2. Check environment variables
    let host = config.host || process.env.DB_HOST || process.env.MYSQL_HOST;
    let user = config.user || process.env.DB_USER || process.env.MYSQL_USER;
    let password = config.password !== undefined ? config.password : (process.env.DB_PASSWORD || process.env.MYSQL_PASSWORD || '');
    let database = config.database || process.env.DB_NAME || process.env.MYSQL_DATABASE;
    let port = Number(config.port || process.env.DB_PORT || process.env.MYSQL_PORT || 3306);
    let useSsl = config.ssl ?? (process.env.DB_SSL === 'true' || process.env.MYSQL_SSL === 'true');

    // 3. Check saved data/db_config.json if not in env
    if ((!host || !user || !database) && fs.existsSync(CONFIG_FILE)) {
      try {
        const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
        if (saved && saved.host && saved.user && saved.database) {
          host = saved.host;
          user = saved.user;
          password = saved.password || '';
          database = saved.database;
          port = Number(saved.port || 3306);
          if (saved.ssl !== undefined) useSsl = Boolean(saved.ssl);
        }
      } catch (err) {
        console.warn('[Hostinger MySQL] Aviso ao ler db_config.json:', err);
      }
    }

    // If still no MySQL credentials configured, gracefully stay in file-based storage mode
    if (!host || !user || !database) {
      this.isConnected = false;
      this.connectionError = 'Credenciais MySQL não configuradas no servidor (DB_HOST, DB_USER, DB_NAME ou aba Banco de Dados).';
      return false;
    }

    try {
      if (this.pool) {
        try {
          await this.pool.end();
        } catch (_) {}
      }

      this.activeConfig = { host, user, database, port, ssl: useSsl };

      this.pool = mysql.createPool({
        host,
        port,
        user,
        password,
        database,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        enableKeepAlive: true,
        keepAliveInitialDelay: 10000,
        connectTimeout: 10000,
        ssl: useSsl ? { rejectUnauthorized: false } : undefined
      });

      // Test connection
      await this.pool.query('SELECT 1 as test');
      this.isConnected = true;
      this.connectionError = null;
      console.log(`[Hostinger MySQL] Conectado com sucesso ao banco '${database}' em ${host}:${port}`);

      // Ensure tables exist
      await this.createTablesIfNotExist();
      return true;
    } catch (err: any) {
      this.isConnected = false;
      this.connectionError = err?.message || 'Falha ao conectar ao banco MySQL';
      console.warn(`[Hostinger MySQL] Conexão falhou: ${this.connectionError}.`);
      return false;
    }
  }

  public async saveConfigAndConnect(config: MySqlConfig): Promise<{ success: boolean; message: string; diagnostics?: any }> {
    try {
      // First test credentials
      const testResult = await this.testConnection(config);
      if (!testResult.success) {
        return {
          success: false,
          message: `Falha no teste de conexão: ${testResult.message}`
        };
      }

      // Save to data/db_config.json
      const dataDir = path.dirname(CONFIG_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf-8');

      // Initialize connection with new config
      const connected = await this.init(config);
      if (!connected) {
        return {
          success: false,
          message: `Credenciais salvas, mas houve erro ao abrir o pool MySQL: ${this.connectionError}`
        };
      }

      // Populate tables with demo data if needed
      await this.seedAllDemoData(false);

      const diag = await this.getLiveDiagnostics();
      return {
        success: true,
        message: 'Configuração salva com sucesso! Conexão com o MySQL da Hostinger estabelecida e tabelas prontas.',
        diagnostics: diag
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Erro ao salvar e conectar: ${err?.message || 'Erro desconhecido'}`
      };
    }
  }

  public async testConnection(config: MySqlConfig): Promise<{ success: boolean; message: string; latencyMs?: number }> {
    const startTime = Date.now();
    try {
      const host = (config.host || 'localhost').trim();
      const useSsl = config.ssl ?? (process.env.DB_SSL === 'true' || process.env.MYSQL_SSL === 'true');
      const conn = await mysql.createConnection({
        host,
        port: Number(config.port || 3306),
        user: (config.user || 'root').trim(),
        password: config.password || '',
        database: (config.database || 'planiloja').trim(),
        connectTimeout: 8000,
        ssl: useSsl ? { rejectUnauthorized: false } : undefined
      });

      await conn.query('SELECT 1');
      await conn.end();

      const latencyMs = Date.now() - startTime;
      return {
        success: true,
        message: `Conexão bem-sucedida com o servidor MySQL! (Latência: ${latencyMs}ms)`,
        latencyMs
      };
    } catch (err: any) {
      let friendlyMessage = err?.message || 'Não foi possível conectar ao banco de dados.';

      if (err?.code === 'ECONNREFUSED') {
        if (!config.host || config.host === 'localhost' || config.host === '127.0.0.1') {
          friendlyMessage = `O host 'localhost' não possui MySQL ativo dentro do container em nuvem. Na Hostinger (onde o MySQL roda no mesmo servidor), 'localhost' funciona automaticamente. Para conectar ao MySQL da Hostinger a partir daqui, informe o IP do servidor e habilite 'Acesso Remoto MySQL' no hPanel da Hostinger.`;
        } else {
          friendlyMessage = `Conexão recusada em ${config.host}:${config.port || 3306}. Verifique se a porta 3306 está aberta e se o MySQL está ativo.`;
        }
      } else if (err?.code === 'EAI_AGAIN' || err?.code === 'ENOTFOUND') {
        friendlyMessage = `Não foi possível localizar o host '${config.host}' via DNS. Dica para Hostinger: Em vez de usar o nome de domínio, use o endereço de IP do servidor (disponível no hPanel em 'Hospedagem' > 'Detalhes do Plano' > 'IP do Servidor') e libere o 'Acesso Remoto MySQL'.`;
      } else if (err?.code === 'ER_ACCESS_DENIED_ERROR') {
        friendlyMessage = `Acesso negado para o usuário '${config.user}'. Verifique se o usuário e a senha cadastrados no hPanel da Hostinger estão corretos. Dica: Caso tenha ativado Acesso Remoto no hPanel, confirme se o usuário tem permissão para conexões externas (host '%').`;
      } else if (err?.code === 'ER_BAD_DB_ERROR') {
        friendlyMessage = `O banco de dados '${config.database}' não foi encontrado. Certifique-se de que o nome completo (ex: u123456789_banco) foi criado no menu 'Bancos de Dados MySQL' do hPanel.`;
      } else if (err?.code === 'ETIMEDOUT' || err?.code === 'PROTOCOL_CONNECTION_LOST' || err?.code === 'EHOSTUNREACH') {
        friendlyMessage = `Tempo limite esgotado ao tentar conectar a '${config.host}'. Para acessar o MySQL da Hostinger fora do servidor web, acesse o hPanel > 'Bancos de Dados' > 'Acesso Remoto MySQL' e adicione permissão para conexões externas ('%' ou IP).`;
      }

      return {
        success: false,
        message: friendlyMessage
      };
    }
  }

  public async getLiveDiagnostics() {
    let counts = {
      stores: 0,
      products: 0,
      categories: 0,
      platforms: 0,
      clicks: 0
    };

    let latencyMs = 0;

    if (this.pool && this.isConnected) {
      try {
        const start = Date.now();
        await this.pool.query('SELECT 1');
        latencyMs = Date.now() - start;

        const [sRows]: any = await this.pool.query('SELECT COUNT(*) as cnt FROM stores');
        const [pRows]: any = await this.pool.query('SELECT COUNT(*) as cnt FROM products');
        const [cRows]: any = await this.pool.query('SELECT COUNT(*) as cnt FROM categories');
        const [platRows]: any = await this.pool.query('SELECT COUNT(*) as cnt FROM platforms');
        const [clkRows]: any = await this.pool.query('SELECT COUNT(*) as cnt FROM clicks');

        counts = {
          stores: Number(sRows[0]?.cnt || 0),
          products: Number(pRows[0]?.cnt || 0),
          categories: Number(cRows[0]?.cnt || 0),
          platforms: Number(platRows[0]?.cnt || 0),
          clicks: Number(clkRows[0]?.cnt || 0)
        };
      } catch (err: any) {
        console.warn('[Hostinger MySQL] Erro ao obter contagens das tabelas:', err);
      }
    }

    return {
      connected: this.isConnected,
      driver: this.isConnected ? 'Hostinger MySQL / MariaDB (Ativo)' : 'Armazenamento JSON Local (Modo Fallback)',
      error: this.connectionError,
      host: this.activeConfig?.host || process.env.DB_HOST || 'Local / Não configurado',
      database: this.activeConfig?.database || process.env.DB_NAME || 'store_data.json',
      user: this.activeConfig?.user || process.env.DB_USER || 'Nenhum',
      port: this.activeConfig?.port || process.env.DB_PORT || 3306,
      latencyMs: this.isConnected ? latencyMs : undefined,
      tableCounts: counts
    };
  }

  public async createTablesIfNotExist(): Promise<void> {
    if (!this.pool) return;

    const createStoresTable = `
      CREATE TABLE IF NOT EXISTS stores (
        id VARCHAR(64) PRIMARY KEY,
        slug VARCHAR(128) UNIQUE NOT NULL,
        storeName VARCHAR(255) NOT NULL,
        logo TEXT,
        instagram VARCHAR(255),
        facebook VARCHAR(255),
        tiktok VARCHAR(255),
        pixelFacebook VARCHAR(255),
        googleAnalytics VARCHAR(255),
        googleAds VARCHAR(255),
        corPrimaria VARCHAR(32) DEFAULT '#2A5C3F',
        corSecundaria VARCHAR(32) DEFAULT '#1B1B1B',
        bannerUrl TEXT,
        bannerLink VARCHAR(255),
        bannerTag VARCHAR(255),
        bannerTitulo VARCHAR(255),
        bannerSubtitulo TEXT,
        tituloSite VARCHAR(255),
        descricaoSite TEXT,
        lojaAtiva TINYINT(1) DEFAULT 1,
        msgManutencao TEXT,
        mensagemTopo TEXT,
        corBarraTopo VARCHAR(32) DEFAULT '#2A5C3F',
        cnpj VARCHAR(64),
        endereco TEXT,
        email VARCHAR(255),
        canalWhatsapp VARCHAR(255),
        canalTelegram VARCHAR(255),
        botaoCanalFlutuante TINYINT(1) DEFAULT 1,
        textoDisclosure TEXT,
        avisoPrecos TEXT,
        adminUser VARCHAR(128) DEFAULT 'admin',
        adminEmail VARCHAR(255) DEFAULT 'admin@loja.com.br',
        adminPassword VARCHAR(255) DEFAULT 'admin',
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createProductsTable = `
      CREATE TABLE IF NOT EXISTS products (
        id VARCHAR(64) PRIMARY KEY,
        storeId VARCHAR(64) NOT NULL,
        ativo TINYINT(1) DEFAULT 1,
        tipo VARCHAR(32) DEFAULT 'FISICO',
        plataforma VARCHAR(64) DEFAULT 'Amazon',
        categoria VARCHAR(128) DEFAULT 'Geral',
        subcategoria VARCHAR(128),
        nome VARCHAR(255) NOT NULL,
        descricao TEXT,
        preco DECIMAL(10,2) DEFAULT 0.00,
        precoPromo DECIMAL(10,2) NULL,
        cupom VARCHAR(64),
        validade VARCHAR(64),
        linkAfiliado TEXT,
        textoBotao VARCHAR(128),
        video VARCHAR(255),
        img1 LONGTEXT,
        img2 LONGTEXT,
        img3 LONGTEXT,
        img4 LONGTEXT,
        ordem INT DEFAULT 1,
        destaque TINYINT(1) DEFAULT 0,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_store (storeId),
        INDEX idx_categoria (categoria),
        INDEX idx_plataforma (plataforma),
        INDEX idx_ativo_ordem (ativo, ordem)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createCategoriesTable = `
      CREATE TABLE IF NOT EXISTS categories (
        id VARCHAR(64) PRIMARY KEY,
        storeId VARCHAR(64) NOT NULL,
        nome VARCHAR(128) NOT NULL,
        slug VARCHAR(128) NOT NULL,
        icone VARCHAR(64),
        descricao TEXT,
        ativo TINYINT(1) DEFAULT 1,
        ordem INT DEFAULT 1,
        ordemMenu INT DEFAULT 1,
        mostrarNoMenu TINYINT(1) DEFAULT 1,
        exibirNoMenu TINYINT(1) DEFAULT 1,
        subcategorias TEXT,
        INDEX idx_cat_store (storeId)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createPlatformsTable = `
      CREATE TABLE IF NOT EXISTS platforms (
        id VARCHAR(64) PRIMARY KEY,
        storeId VARCHAR(64) NOT NULL,
        nome VARCHAR(128) NOT NULL,
        slug VARCHAR(128) NOT NULL,
        cor VARCHAR(32) DEFAULT '#2A5C3F',
        badge VARCHAR(64),
        icone VARCHAR(64),
        ativo TINYINT(1) DEFAULT 1,
        ordem INT DEFAULT 1,
        INDEX idx_plat_store (storeId)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createClicksTable = `
      CREATE TABLE IF NOT EXISTS clicks (
        id VARCHAR(64) PRIMARY KEY,
        storeId VARCHAR(64) NOT NULL,
        productId VARCHAR(64),
        produto VARCHAR(255),
        plataforma VARCHAR(64),
        tipo VARCHAR(32),
        categoria VARCHAR(128),
        origem VARCHAR(128),
        utm_source VARCHAR(128),
        utm_medium VARCHAR(128),
        utm_campaign VARCHAR(128),
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_click_store (storeId),
        INDEX idx_click_created (createdAt)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createStoreViewsTable = `
      CREATE TABLE IF NOT EXISTS store_views (
        storeSlug VARCHAR(128) PRIMARY KEY,
        viewsCount INT DEFAULT 0,
        lastViewAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    const createUsersTable = `
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(64) PRIMARY KEY,
        storeId VARCHAR(64) NOT NULL,
        nome VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        username VARCHAR(128) NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(32) DEFAULT 'ADMIN',
        ativo TINYINT(1) DEFAULT 1,
        avatar TEXT,
        ultimoAcesso TIMESTAMP NULL DEFAULT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_store (storeId),
        INDEX idx_user_login (username, email)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
    `;

    await this.pool.query(createStoresTable);
    await this.pool.query(createProductsTable);
    await this.pool.query(createCategoriesTable);
    await this.pool.query(createPlatformsTable);
    await this.pool.query(createClicksTable);
    await this.pool.query(createStoreViewsTable);
    await this.pool.query(createUsersTable);
  }

  // ============================================
  // MYSQL PERSISTENCE OPERATIONS
  // ============================================

  public async saveProduct(p: Product): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query(`
        INSERT INTO products (
          id, storeId, ativo, tipo, plataforma, categoria, subcategoria,
          nome, descricao, preco, precoPromo, cupom, validade,
          linkAfiliado, textoBotao, video, img1, img2, img3, img4,
          ordem, destaque
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          ativo=VALUES(ativo),
          tipo=VALUES(tipo),
          plataforma=VALUES(plataforma),
          categoria=VALUES(categoria),
          subcategoria=VALUES(subcategoria),
          nome=VALUES(nome),
          descricao=VALUES(descricao),
          preco=VALUES(preco),
          precoPromo=VALUES(precoPromo),
          cupom=VALUES(cupom),
          validade=VALUES(validade),
          linkAfiliado=VALUES(linkAfiliado),
          textoBotao=VALUES(textoBotao),
          video=VALUES(video),
          img1=VALUES(img1),
          img2=VALUES(img2),
          img3=VALUES(img3),
          img4=VALUES(img4),
          ordem=VALUES(ordem),
          destaque=VALUES(destaque),
          updatedAt=CURRENT_TIMESTAMP
      `, [
        p.id,
        p.storeId || 'store-1',
        p.ativo ? 1 : 0,
        p.tipo || 'FISICO',
        p.plataforma || 'Amazon',
        p.categoria || 'Geral',
        p.subcategoria || '',
        p.nome || 'Produto',
        p.descricao || '',
        Number(p.preco) || 0,
        p.precoPromo !== null && p.precoPromo !== undefined ? Number(p.precoPromo) : null,
        p.cupom || '',
        p.validade || '',
        p.linkAfiliado || '',
        p.textoBotao || '',
        p.video || '',
        p.img1 || '',
        p.img2 || '',
        p.img3 || '',
        p.img4 || '',
        Number(p.ordem) || 1,
        p.destaque ? 1 : 0
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao salvar produto no MySQL:', err);
    }
  }

  public async deleteProduct(id: string): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query('DELETE FROM products WHERE id = ?', [id]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao deletar produto do MySQL:', err);
    }
  }

  public async saveCategory(c: Category): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      const inMenu = c.mostrarNoMenu !== false ? 1 : 0;
      const order = c.ordem || 1;
      const subs = Array.isArray(c.subcategorias) ? JSON.stringify(c.subcategorias) : '[]';

      await this.pool.query(`
        INSERT INTO categories (id, storeId, nome, slug, icone, descricao, ativo, ordem, ordemMenu, mostrarNoMenu, exibirNoMenu, subcategorias)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          nome=VALUES(nome),
          slug=VALUES(slug),
          icone=VALUES(icone),
          descricao=VALUES(descricao),
          ativo=VALUES(ativo),
          ordem=VALUES(ordem),
          ordemMenu=VALUES(ordemMenu),
          mostrarNoMenu=VALUES(mostrarNoMenu),
          exibirNoMenu=VALUES(exibirNoMenu),
          subcategorias=VALUES(subcategorias)
      `, [
        c.id,
        c.storeId || 'store-1',
        c.nome,
        c.nome.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        c.icone || 'Sparkles',
        c.descricao || '',
        1,
        order,
        order,
        inMenu,
        inMenu,
        subs
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao salvar categoria no MySQL:', err);
    }
  }

  public async deleteCategory(id: string): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query('DELETE FROM categories WHERE id = ?', [id]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao deletar categoria do MySQL:', err);
    }
  }

  public async savePlatform(plat: Platform): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query(`
        INSERT INTO platforms (id, storeId, nome, slug, cor, badge, icone, ativo, ordem)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          nome=VALUES(nome),
          slug=VALUES(slug),
          cor=VALUES(cor),
          badge=VALUES(badge),
          icone=VALUES(icone),
          ativo=VALUES(ativo),
          ordem=VALUES(ordem)
      `, [
        plat.id,
        plat.storeId || 'store-1',
        plat.nome,
        plat.nome.toLowerCase().replace(/[^a-z0-9]/g, '-'),
        plat.corBadge || '#2A5C3F',
        plat.textoBotaoPadrao || '',
        plat.icone || '',
        plat.ativo !== false ? 1 : 0,
        plat.ordem || 1
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao salvar plataforma no MySQL:', err);
    }
  }

  public async deletePlatform(id: string): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query('DELETE FROM platforms WHERE id = ?', [id]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao deletar plataforma do MySQL:', err);
    }
  }

  public async saveUser(u: StoreUser): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query(`
        INSERT INTO users (
          id, storeId, nome, email, username, password, role, ativo, avatar, ultimoAcesso
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          nome=VALUES(nome),
          email=VALUES(email),
          username=VALUES(username),
          password=IF(VALUES(password) != '', VALUES(password), password),
          role=VALUES(role),
          ativo=VALUES(ativo),
          avatar=VALUES(avatar),
          ultimoAcesso=VALUES(ultimoAcesso),
          updatedAt=CURRENT_TIMESTAMP
      `, [
        u.id,
        u.storeId || 'store-1',
        u.nome || 'Usuário',
        u.email || '',
        u.username || '',
        u.password || '',
        u.role || 'ADMIN',
        u.ativo !== false ? 1 : 0,
        u.avatar || '',
        u.ultimoAcesso ? new Date(u.ultimoAcesso) : null
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao salvar usuário no MySQL:', err);
    }
  }

  public async deleteUser(id: string): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query('DELETE FROM users WHERE id = ?', [id]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao deletar usuário do MySQL:', err);
    }
  }

  public async saveStore(s: StoreConfig): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query(`
        INSERT INTO stores (
          id, slug, storeName, logo, instagram, facebook, tiktok,
          pixelFacebook, googleAnalytics, googleAds,
          corPrimaria, corSecundaria, bannerUrl, bannerLink, bannerTag,
          bannerTitulo, bannerSubtitulo, tituloSite, descricaoSite, lojaAtiva,
          msgManutencao, mensagemTopo, corBarraTopo, cnpj, endereco, email,
          canalWhatsapp, canalTelegram, botaoCanalFlutuante, textoDisclosure, avisoPrecos,
          adminUser, adminEmail, adminPassword
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          storeName=VALUES(storeName),
          logo=VALUES(logo),
          instagram=VALUES(instagram),
          facebook=VALUES(facebook),
          tiktok=VALUES(tiktok),
          pixelFacebook=VALUES(pixelFacebook),
          googleAnalytics=VALUES(googleAnalytics),
          googleAds=VALUES(googleAds),
          corPrimaria=VALUES(corPrimaria),
          corSecundaria=VALUES(corSecundaria),
          bannerUrl=VALUES(bannerUrl),
          bannerLink=VALUES(bannerLink),
          bannerTag=VALUES(bannerTag),
          bannerTitulo=VALUES(bannerTitulo),
          bannerSubtitulo=VALUES(bannerSubtitulo),
          tituloSite=VALUES(tituloSite),
          descricaoSite=VALUES(descricaoSite),
          lojaAtiva=VALUES(lojaAtiva),
          msgManutencao=VALUES(msgManutencao),
          mensagemTopo=VALUES(mensagemTopo),
          corBarraTopo=VALUES(corBarraTopo),
          cnpj=VALUES(cnpj),
          endereco=VALUES(endereco),
          email=VALUES(email),
          canalWhatsapp=VALUES(canalWhatsapp),
          canalTelegram=VALUES(canalTelegram),
          botaoCanalFlutuante=VALUES(botaoCanalFlutuante),
          textoDisclosure=VALUES(textoDisclosure),
          avisoPrecos=VALUES(avisoPrecos),
          adminUser=VALUES(adminUser),
          adminEmail=VALUES(adminEmail),
          adminPassword=VALUES(adminPassword),
          updatedAt=CURRENT_TIMESTAMP
      `, [
        s.id || 'store-1',
        s.slug || 'achadinhos-da-maria',
        s.storeName || 'Minha Loja',
        s.logo || '',
        s.instagram || '',
        s.facebook || '',
        s.tiktok || '',
        s.pixelFacebook || '',
        s.googleAnalytics || '',
        s.googleAds || '',
        s.corPrimaria || '#2A5C3F',
        s.corSecundaria || '#1B1B1B',
        s.bannerUrl || '',
        s.bannerLink || '',
        s.bannerTag || '',
        s.bannerTitulo || '',
        s.bannerSubtitulo || '',
        s.tituloSite || '',
        s.descricaoSite || '',
        s.lojaAtiva !== false ? 1 : 0,
        s.msgManutencao || '',
        s.mensagemTopo || '',
        s.corBarraTopo || '#2A5C3F',
        s.cnpj || '',
        s.endereco || '',
        s.email || '',
        s.canalWhatsapp || '',
        s.canalTelegram || '',
        s.botaoCanalFlutuante !== false ? 1 : 0,
        s.textoDisclosure || '',
        s.avisoPrecos || '',
        s.adminUser || 'admin',
        s.adminEmail || 'admin@loja.com.br',
        s.adminPassword || 'admin'
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao salvar loja no MySQL:', err);
    }
  }

  public async saveClick(click: ClickRecord): Promise<void> {
    if (!this.pool || !this.isConnected) return;
    try {
      await this.pool.query(`
        INSERT INTO clicks (id, storeId, productId, produto, plataforma, tipo, categoria, origem, utm_source, utm_medium, utm_campaign)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        click.id,
        click.storeId || 'store-1',
        click.productId || '',
        click.produto || '',
        click.plataforma || '',
        click.tipo || 'FISICO',
        click.categoria || '',
        click.origem || 'CARD',
        click.utm_source || '',
        click.utm_medium || '',
        click.utm_campaign || ''
      ]);
    } catch (err) {
      console.error('[Hostinger MySQL] Erro ao registrar clique no MySQL:', err);
    }
  }

  public async syncAllData(data: { stores: StoreConfig[]; products: Product[]; categories: Category[]; platforms: Platform[] }): Promise<{ success: boolean; message: string; counts: any }> {
    if (!this.pool || !this.isConnected) {
      return {
        success: false,
        message: 'MySQL não está conectado. Conecte primeiro o banco de dados.',
        counts: { stores: 0, products: 0, categories: 0, platforms: 0 }
      };
    }

    try {
      for (const store of data.stores) {
        await this.saveStore(store);
      }
      for (const cat of data.categories) {
        await this.saveCategory(cat);
      }
      for (const plat of data.platforms) {
        await this.savePlatform(plat);
      }
      for (const prod of data.products) {
        await this.saveProduct(prod);
      }

      const diag = await this.getLiveDiagnostics();
      return {
        success: true,
        message: `Sincronização concluída com sucesso! ${data.products.length} produtos gravados no MySQL da Hostinger.`,
        counts: diag.tableCounts
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Erro durante sincronização no MySQL: ${err?.message || 'Erro desconhecido'}`,
        counts: { stores: 0, products: 0, categories: 0, platforms: 0 }
      };
    }
  }

  public async seedAllDemoData(force: boolean = false): Promise<{ success: boolean; insertedCount: number; message: string }> {
    if (!this.pool) {
      return { success: false, insertedCount: 0, message: 'MySQL não está conectado. Configure as variáveis DB_HOST, DB_USER, DB_NAME ou salve as credenciais na aba Banco de Dados.' };
    }

    try {
      console.log('[Hostinger MySQL] Semeando dados completos no banco de dados...');
      
      // 1. Store
      await this.pool.query(`
        INSERT INTO stores (
          id, slug, storeName, logo, instagram, facebook, tiktok,
          corPrimaria, corSecundaria, bannerUrl, bannerLink, bannerTag,
          bannerTitulo, bannerSubtitulo, tituloSite, descricaoSite, lojaAtiva,
          mensagemTopo, corBarraTopo, email, textoDisclosure, adminUser, adminEmail, adminPassword
        ) VALUES (
          'store-1', 'achadinhos-da-maria', 'Achadinhos da Maria',
          'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800&auto=format&fit=crop&q=80&fm=webp',
          '@achadinhosdamaria', 'facebook.com/achadinhosdamaria', '@achadinhosdamaria',
          '#2A5C3F', '#1B1B1B',
          'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&auto=format&fit=crop&q=80&fm=webp',
          'Eletrônicos', 'SELEÇÃO ESPECIAL', 'Ofertas Imperdíveis do Dia',
          'Achadinhos com até 60% de desconto e cupons exclusivos testados.',
          'Achadinhos da Maria — As Melhores Ofertas e Promoções',
          'Achadinhos imperdíveis da internet, produtos recomendados na Amazon, Shopee, Mercado Livre e Magalu.',
          1, '🔥 Frete Grátis e Cupons Exclusivos adicionados hoje! Aproveite antes que acabem.',
          '#2A5C3F', 'admin@achadinhosdamaria.com.br',
          'Este site participa de programas de afiliados e pode receber comissão pelas compras realizadas nos links, sem custo adicional para você.',
          'admin', 'admin@achadinhosdamaria.com.br',
          '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.qH0fQY6iKz7j8aR3Fw9rL5q2O.c4M12'
        ) ON DUPLICATE KEY UPDATE storeName=VALUES(storeName), lojaAtiva=1
      `);

      // 2. Categories
      await this.pool.query(`
        INSERT INTO categories (id, storeId, nome, slug, icone, ativo, ordemMenu, exibirNoMenu) VALUES
        ('cat-1', 'store-1', 'Eletrônicos', 'eletronicos', 'Laptop', 1, 1, 1),
        ('cat-2', 'store-1', 'Casa & Cozinha', 'casa-cozinha', 'Home', 1, 2, 1),
        ('cat-3', 'store-1', 'Beleza & Cuidados', 'beleza-cuidados', 'Sparkles', 1, 3, 1),
        ('cat-4', 'store-1', 'Moda & Acessórios', 'moda-acessorios', 'ShoppingBag', 1, 4, 1),
        ('cat-5', 'store-1', 'Cursos & Livros', 'cursos-livros', 'BookOpen', 1, 5, 1)
        ON DUPLICATE KEY UPDATE nome=VALUES(nome), ativo=1
      `);

      // 3. Platforms
      await this.pool.query(`
        INSERT INTO platforms (id, storeId, nome, slug, cor, badge, icone, ativo, ordem) VALUES
        ('plat-1', 'store-1', 'Amazon', 'amazon', '#FF9900', 'Prime', 'ShoppingBag', 1, 1),
        ('plat-2', 'store-1', 'Shopee', 'shopee', '#EE4D2D', 'Frete Grátis', 'ShoppingBag', 1, 2),
        ('plat-3', 'store-1', 'Mercado Livre', 'mercado-livre', '#EAB308', 'Full', 'ShoppingBag', 1, 3),
        ('plat-4', 'store-1', 'Magalu', 'magalu', '#0086FF', 'Oferta', 'ShoppingBag', 1, 4),
        ('plat-5', 'store-1', 'Hotmart', 'hotmart', '#F97316', 'Digital', 'ShoppingBag', 1, 5)
        ON DUPLICATE KEY UPDATE nome=VALUES(nome), ativo=1
      `);

      // 4. Products
      await this.pool.query(`
        INSERT INTO products (
          id, storeId, ativo, tipo, plataforma, categoria, subcategoria,
          nome, descricao, preco, precoPromo, cupom, validade,
          linkAfiliado, textoBotao, video, img1, img2, img3, img4,
          ordem, destaque
        ) VALUES
        (
          'prod-1', 'store-1', 1, 'FISICO', 'Amazon', 'Eletrônicos', 'Áudio',
          'Fone de Ouvido Bluetooth JBL Tune 520BT com Som Pure Bass',
          'Fone sem fio JBL Tune 520BT com bateria de até 57 horas de reprodução, carregamento rápido (5 minutos = 3 horas), microfone integrado para chamadas mãos livres e conexão multipontos para alternar entre dispositivos facilmente.',
          299.00, 219.90, 'JBL10OFF', '2027-12-31',
          'https://amazon.com.br?tag=achadinhos-maria-20', 'Ver oferta na Amazon →', '',
          'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80&fm=webp',
          'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=80&fm=webp',
          'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80&fm=webp', '',
          1, 1
        ),
        (
          'prod-2', 'store-1', 1, 'FISICO', 'Shopee', 'Casa & Cozinha', 'Eletroportáteis',
          'Fritadeira Elétrica Air Fryer Digital 4.5L Inox',
          'Air Fryer com painel touch digital, 8 funções pré-programadas, cesto antiaderente removível com revestimento cerâmico e timer sonoro de 60 minutos. Cozinha alimentos crocantes com até 80% menos óleo.',
          459.90, 289.00, 'AIRFRYER20', '2027-12-31',
          'https://shopee.com.br?affiliate=achadinhos', 'Pegar Desconto na Shopee →', '',
          'https://images.unsplash.com/photo-1585659722983-3a675dabf23d?w=800&auto=format&fit=crop&q=80&fm=webp',
          'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
          2, 1
        ),
        (
          'prod-3', 'store-1', 1, 'FISICO', 'Mercado Livre', 'Eletrônicos', 'Wearables',
          'Smartwatch Xiaomi Smart Band 8 Tela AMOLED 1.62\"',
          'Pulseira inteligente com mais de 150 modos esportivos, monitoramento contínuo de frequência cardíaca e oxigênio no sangue (SpO2), bateria com autonomia de até 16 dias e resistência à água de 5 ATM (50 metros).',
          249.00, 189.90, 'MELLIBRE15', '2027-12-31',
          'https://mercadolivre.com.br/sec/promo', 'Ver no Mercado Livre →', '',
          'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80&fm=webp',
          'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
          3, 1
        ),
        (
          'prod-4', 'store-1', 1, 'FISICO', 'Amazon', 'Casa & Cozinha', 'Organização',
          'Kit 6 Potes Herméticos de Vidro com Tampa de Bambu',
          'Conjunto com 6 potes de vidro borossilicato resistente a calor e choque térmico com tampas herméticas em bambu natural e anel de silicone. Ideais para mantimentos, grãos, café e organização estética de despensa.',
          169.90, 119.00, 'CASA10', '2027-12-31',
          'https://amazon.com.br?tag=achadinhos-maria-20', 'Ver oferta na Amazon →', '',
          'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80&fm=webp',
          'https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
          4, 0
        ),
        (
          'prod-5', 'store-1', 1, 'FISICO', 'Magalu', 'Beleza & Cuidados', 'Cabelos',
          'Escova Secadora e Modeladora 3 em 1 Cerâmica Íons 1200W',
          'Seca, alisa e modela com cerdas macias anti-frizz e tecnologia de íons negativos que selam as cutículas dos fios. Possui 3 temperaturas ajustáveis e cabo giratório 360 graus.',
          189.90, 99.90, 'BELEZA25', '2027-12-31',
          'https://magazineluiza.com.br', 'Ver na Magalu →', '',
          'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80&fm=webp',
          '', '', '',
          5, 0
        ),
        (
          'prod-6', 'store-1', 1, 'DIGITAL', 'Hotmart', 'Cursos & Livros', 'Desenvolvimento',
          'Curso Completo de Marketing para Afiliados e Tráfego Pago',
          'Aprenda do zero ao avançado como criar campanhas de alto retorno, encontrar produtos vencedores e estruturar uma renda recorrente com programas de afiliados globais.',
          497.00, 197.00, 'DESCONTOVIP', '2027-12-31',
          'https://hotmart.com', 'Quero Conhecer o Curso →', '',
          'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&auto=format&fit=crop&q=80&fm=webp',
          '', '', '',
          6, 0
        ),
        (
          'prod-7', 'store-1', 1, 'FISICO', 'Shopee', 'Eletrônicos', 'Acessórios',
          'Luminária de Mesa LED Articulada Recarregável Touch com Porta-Caneta',
          'Lâmpada de mesa com 3 intensidades de luz (quente, fria e neutra), haste flexível de silicone, suporte para celular integrado e bateria recarregável USB com até 8h de duração contínua.',
          69.90, 38.50, '', '2027-12-31',
          'https://shopee.com.br', 'Ver Oferta na Shopee →', '',
          'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?w=800&auto=format&fit=crop&q=80&fm=webp',
          '', '', '',
          7, 0
        ),
        (
          'prod-8', 'store-1', 1, 'FISICO', 'Amazon', 'Eletrônicos', 'Dispositivos',
          'Echo Pop Smart Speaker Compacto com Alexa e Som Envolvente',
          'A smart speaker com som surround compacto que cabe perfeitamente em quartos e espaços pequenos. Peça músicas para Alexa, controle dispositivos de casa inteligente, timer, previsão do tempo e muito mais.',
          349.00, 249.00, 'ALEXAPROMO', '2027-12-31',
          'https://amazon.com.br', 'Ver na Amazon →', '',
          'https://images.unsplash.com/photo-1543512214-318c7553f230?w=800&auto=format&fit=crop&q=80&fm=webp',
          '', '', '',
          8, 0
        )
        ON DUPLICATE KEY UPDATE nome=VALUES(nome), preco=VALUES(preco), precoPromo=VALUES(precoPromo), ativo=1
      `);

      return {
        success: true,
        insertedCount: 8,
        message: 'Tabelas do banco de dados da Hostinger populadas com sucesso com a loja e os 8 produtos!'
      };
    } catch (err: any) {
      console.error('[Hostinger MySQL] Erro ao semear tabelas:', err);
      return {
        success: false,
        insertedCount: 0,
        message: `Erro ao semear MySQL: ${err?.message || 'Erro desconhecido'}`
      };
    }
  }
}

export const mysqlManager = new MySqlManager();
