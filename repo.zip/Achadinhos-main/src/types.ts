export type UserRole = 'ADMIN' | 'GERENTE' | 'EDITOR';

export interface StoreUser {
  id: string;
  storeId?: string;
  nome: string;
  email: string;
  username: string;
  password?: string;
  role: UserRole;
  ativo: boolean;
  avatar?: string;
  ultimoAcesso?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface StoreConfig {
  id: string;
  slug: string;
  storeName: string;
  logo: string;
  instagram: string;
  facebook: string;
  tiktok: string;
  pixelFacebook: string;
  googleAnalytics: string;
  googleAds: string;
  corPrimaria: string;
  corSecundaria?: string;
  bannerUrl: string;
  bannerLink: string;
  bannerTag: string;
  bannerTitulo: string;
  bannerSubtitulo: string;
  tituloSite: string;
  descricaoSite: string;
  lojaAtiva: boolean;
  msgManutencao: string;
  mensagemTopo: string;
  corBarraTopo: string;
  cnpj: string;
  endereco: string;
  email: string;
  canalWhatsapp: string;
  canalTelegram: string;
  botaoCanalFlutuante: boolean;
  textoDisclosure: string;
  avisoPrecos: string;
  adminUser?: string;
  adminEmail?: string;
  adminPassword?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface Category {
  id: string;
  storeId: string;
  nome: string;
  mostrarNoMenu: boolean;
  ordem: number;
  descricao?: string;
  icone?: string;
  subcategorias?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface Platform {
  id: string;
  storeId: string;
  nome: string;
  corBadge?: string;
  icone?: string;
  textoBotaoPadrao?: string;
  urlPadrao?: string;
  descricao?: string;
  ordem?: number;
  ativo?: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface Product {
  id: string;
  storeId: string;
  ativo: boolean;
  tipo: 'FISICO' | 'DIGITAL';
  plataforma: string;
  categoria: string;
  subcategoria: string;
  nome: string;
  descricao: string;
  preco: number;
  precoPromo: number | null;
  cupom: string;
  validade: string | null; // ISO string or date
  linkAfiliado: string;
  textoBotao: string;
  video: string;
  img1: string;
  img2: string;
  img3: string;
  img4: string;
  ordem: number;
  destaque: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export interface ClickRecord {
  id: string;
  storeId: string;
  productId?: string;
  produto: string;
  plataforma: string;
  tipo: string;
  categoria: string;
  origem: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  createdAt: string;
}

export interface StoreMetrics {
  views: number;
  totalClicks: number;
  ctr: number;
  couponCopies: number;
  topProducts: {
    nome: string;
    cliques: number;
    categoria: string;
    plataforma: string;
    img?: string;
  }[];
  platforms: { plataforma: string; count: number; percentage: number }[];
  categories: { categoria: string; count: number; percentage: number }[];
  recentClicks: ClickRecord[];
  utms: { source: string; count: number }[];
}

export type PriceMarkupType = 'direct' | 'percentage' | 'fixed';
export type OutOfStockAction = 'pause' | 'keep' | 'notify';

export interface PriceMonitorSettings {
  storeId: string;
  enabled: boolean;
  autoApply: boolean;
  frequencyHours: number; // 0 = manual, 6 = 6h, 12 = 12h, 24 = 24h
  markupType: PriceMarkupType;
  markupValue: number; // e.g. 10 (%) or 15 (R$)
  outOfStockAction: OutOfStockAction;
  notifyPriceChanges: boolean;
  lastSyncAt?: string;
  totalMonitoredProducts?: number;
}

export interface PriceCheckResult {
  productId?: string;
  productName?: string;
  url: string;
  platform: string;
  detectedName?: string;
  detectedImage?: string;
  currentCatalogPrice?: number;
  currentCatalogPromo?: number | null;
  supplierPrice: number | null;
  supplierPromo: number | null;
  calculatedPrice: number | null;
  calculatedPromo: number | null;
  inStock: boolean;
  currency: string;
  diffPercent: number;
  status: 'up' | 'down' | 'unchanged' | 'out_of_stock' | 'error' | 'not_found';
  message?: string;
  checkedAt: string;
}

export interface PriceLogRecord {
  id: string;
  storeId: string;
  productId: string;
  productName: string;
  platform: string;
  oldPrice: number;
  newSupplierPrice: number;
  appliedPrice: number;
  oldPromo: number | null;
  newSupplierPromo: number | null;
  appliedPromo: number | null;
  stockStatus: 'in_stock' | 'out_of_stock';
  actionTaken: 'updated' | 'paused' | 'unchanged' | 'failed';
  createdAt: string;
}

