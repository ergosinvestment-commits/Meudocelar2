# 🚀 Guia Prático Definitivo: Conectar o Achadinhos ao MySQL da Hostinger

Este guia resolve 100% dos erros de conexão e comunicação com o banco de dados na Hostinger.

---

## 🔍 Entenda o que causava o erro "Página HTML (404)"

Quando o site é hospedado na Hostinger em servidores Apache/LiteSpeed (planos Single, Premium, Business ou Cloud), o servidor web por padrão procura arquivos PHP/HTML e não sabe responder requisições `/api/*` a menos que exista um arquivo `.htaccess` e um roteador de API nativo.

Agora o projeto já inclui **suporte nativo automático tanto para PHP nativo quanto para Node.js**, funcionando imediatamente em qualquer plano!

---

## ⚡ Método 1 (Mais Rápido & Garantido): Hospedagem Web Padrão da Hostinger

Este método funciona em **todos os planos da Hostinger** com zero configurações complexas:

### 1. Criar e Popular o Banco no phpMyAdmin
1. No **hPanel da Hostinger**, entre em **Bancos de Dados MySQL**.
2. Anote o **Nome do Banco** (ex: `u566136191_achadinhos`), **Usuário** (ex: `u566136191_achadinhos`) e a **Senha**.
3. Clique em **Entrar no phpMyAdmin** ao lado do seu banco.
4. Na coluna esquerda do phpMyAdmin, clique no nome do seu banco (`u566136191_achadinhos`).
5. No menu do topo, clique na aba **SQL**.
6. Copie todo o conteúdo do arquivo **`schema.sql`**, cole na caixa de texto e clique em **Executar** (*Go*).
   *(Todas as tabelas e o catálogo de produtos serão criados instantaneamente!)*

### 2. Subir os Arquivos para a Hostinger
1. No **Gerenciador de Arquivos** do hPanel, abra a pasta **`public_html`** do seu site (`lightpink-deer-774140.hostingersite.com`).
2. Suba o conteúdo gerado na pasta de publicação (ou os arquivos do projeto):
   - `.htaccess` *(Essencial para rotear `/api` sem erro 404)*
   - `index.html`
   - pasta `assets/`
   - pasta `api/` (com o arquivo `api/index.php`)
   - `config.php`
3. Abra o arquivo **`config.php`** no Gerenciador de Arquivos da Hostinger e preencha sua senha:
   ```php
   $dbHost = 'localhost';
   $dbPort = '3306';
   $dbName = 'u566136191_achadinhos';
   $dbUser = 'u566136191_achadinhos';
   $dbPass = 'SUA_SENHA_AQUI';
   ```
4. Salve o arquivo. **Pronto!** Seu site e seu banco de dados MySQL já estão 100% conversando.

---

## ⚡ Método 2: Usando o Gerenciador Node.js do hPanel (Opcional)

Se você utiliza o Gerenciador Node.js da Hostinger:
1. No menu **Avançado > Node.js**:
   - **Node.js Version**: Selecione `20.x` ou `18.x`.
   - **Application Root**: `/public_html`
   - **Application Startup File**: `dist/server.cjs` ou `server.ts`
2. No arquivo `.env` dentro de `public_html`:
   ```env
   NODE_ENV=production
   PORT=3000
   DB_TYPE=mysql
   DB_HOST=localhost
   DB_PORT=3306
   DB_NAME=u566136191_achadinhos
   DB_USER=u566136191_achadinhos
   DB_PASSWORD=SUA_SENHA_AQUI
   JWT_SECRET=sua_chave_jwt_secreta_aqui
   ```
3. Clique em **Salvar / Iniciar Aplicação**.
