-- ==========================================================
-- PLANILOJA ACHADINHOS - ESQUEMA DE BANCO DE DADOS HOSTINGER
-- Compatível com: MySQL 5.7+, MySQL 8.0+, MariaDB 10.3+
-- Execução: phpMyAdmin / Hostinger hPanel / Console MySQL
-- ==========================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------
-- 1. TABELA DE CONFIGURAÇÃO DA LOJA (STORES)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stores` (
  `id` VARCHAR(64) NOT NULL,
  `slug` VARCHAR(128) NOT NULL,
  `storeName` VARCHAR(255) NOT NULL,
  `logo` TEXT,
  `instagram` VARCHAR(255) DEFAULT '',
  `facebook` VARCHAR(255) DEFAULT '',
  `tiktok` VARCHAR(255) DEFAULT '',
  `pixelFacebook` VARCHAR(255) DEFAULT '',
  `googleAnalytics` VARCHAR(255) DEFAULT '',
  `googleAds` VARCHAR(255) DEFAULT '',
  `corPrimaria` VARCHAR(32) DEFAULT '#2A5C3F',
  `corSecundaria` VARCHAR(32) DEFAULT '#1B1B1B',
  `bannerUrl` TEXT,
  `bannerLink` VARCHAR(255) DEFAULT '',
  `bannerTag` VARCHAR(255) DEFAULT 'SELEÇÃO ESPECIAL',
  `bannerTitulo` VARCHAR(255) DEFAULT 'Ofertas Imperdíveis do Dia',
  `bannerSubtitulo` TEXT,
  `tituloSite` VARCHAR(255) DEFAULT 'Achadinhos da Maria — As Melhores Ofertas',
  `descricaoSite` TEXT,
  `lojaAtiva` TINYINT(1) DEFAULT 1,
  `msgManutencao` TEXT,
  `mensagemTopo` TEXT,
  `corBarraTopo` VARCHAR(32) DEFAULT '#2A5C3F',
  `cnpj` VARCHAR(64) DEFAULT '',
  `endereco` TEXT,
  `email` VARCHAR(255) DEFAULT '',
  `canalWhatsapp` VARCHAR(255) DEFAULT '',
  `canalTelegram` VARCHAR(255) DEFAULT '',
  `botaoCanalFlutuante` TINYINT(1) DEFAULT 1,
  `textoDisclosure` TEXT,
  `avisoPrecos` TEXT,
  `adminUser` VARCHAR(128) DEFAULT 'admin',
  `adminEmail` VARCHAR(255) DEFAULT 'admin@achadinhosdamaria.com.br',
  `adminPassword` VARCHAR(255) DEFAULT 'admin',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 2. TABELA DE PRODUTOS (PRODUCTS)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `products` (
  `id` VARCHAR(64) NOT NULL,
  `storeId` VARCHAR(64) NOT NULL,
  `ativo` TINYINT(1) DEFAULT 1,
  `tipo` VARCHAR(32) DEFAULT 'FISICO',
  `plataforma` VARCHAR(64) DEFAULT 'Amazon',
  `categoria` VARCHAR(128) DEFAULT 'Geral',
  `subcategoria` VARCHAR(128) DEFAULT '',
  `nome` VARCHAR(255) NOT NULL,
  `descricao` TEXT,
  `preco` DECIMAL(10,2) DEFAULT 0.00,
  `precoPromo` DECIMAL(10,2) NULL,
  `cupom` VARCHAR(64) DEFAULT '',
  `validade` VARCHAR(64) NULL,
  `linkAfiliado` TEXT,
  `textoBotao` VARCHAR(128) DEFAULT 'Ver oferta na loja →',
  `video` VARCHAR(255) DEFAULT '',
  `img1` TEXT,
  `img2` TEXT,
  `img3` TEXT,
  `img4` TEXT,
  `ordem` INT DEFAULT 1,
  `destaque` TINYINT(1) DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_store` (`storeId`),
  KEY `idx_categoria` (`categoria`),
  KEY `idx_plataforma` (`plataforma`),
  KEY `idx_ativo_ordem` (`ativo`, `ordem`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 3. TABELA DE CATEGORIAS (CATEGORIES)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `categories` (
  `id` VARCHAR(64) NOT NULL,
  `storeId` VARCHAR(64) NOT NULL,
  `nome` VARCHAR(128) NOT NULL,
  `slug` VARCHAR(128) NOT NULL,
  `icone` VARCHAR(64) DEFAULT 'Sparkles',
  `descricao` TEXT NULL,
  `ativo` TINYINT(1) DEFAULT 1,
  `ordem` INT DEFAULT 1,
  `ordemMenu` INT DEFAULT 1,
  `mostrarNoMenu` TINYINT(1) DEFAULT 1,
  `exibirNoMenu` TINYINT(1) DEFAULT 1,
  `subcategorias` TEXT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_cat_store` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 4. TABELA DE PLATAFORMAS DE AFILIADOS (PLATFORMS)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `platforms` (
  `id` VARCHAR(64) NOT NULL,
  `storeId` VARCHAR(64) NOT NULL,
  `nome` VARCHAR(128) NOT NULL,
  `slug` VARCHAR(128) NOT NULL,
  `cor` VARCHAR(32) DEFAULT '#2A5C3F',
  `badge` VARCHAR(64) DEFAULT '',
  `icone` VARCHAR(64) DEFAULT 'ShoppingBag',
  `ativo` TINYINT(1) DEFAULT 1,
  `ordem` INT DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_plat_store` (`storeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 5. TABELA DE CLIQUE & ANALYTICS (CLICKS)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clicks` (
  `id` VARCHAR(64) NOT NULL,
  `storeId` VARCHAR(64) NOT NULL,
  `productId` VARCHAR(64) DEFAULT NULL,
  `produto` VARCHAR(255) DEFAULT '',
  `plataforma` VARCHAR(64) DEFAULT '',
  `tipo` VARCHAR(32) DEFAULT 'FISICO',
  `categoria` VARCHAR(128) DEFAULT '',
  `origem` VARCHAR(128) DEFAULT 'Direto',
  `utm_source` VARCHAR(128) DEFAULT NULL,
  `utm_medium` VARCHAR(128) DEFAULT NULL,
  `utm_campaign` VARCHAR(128) DEFAULT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_click_store` (`storeId`),
  KEY `idx_click_created` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 6. TABELA DE VISITAS DA LOJA (STORE_VIEWS)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `store_views` (
  `storeSlug` VARCHAR(128) NOT NULL,
  `viewsCount` INT DEFAULT 0,
  `lastViewAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`storeSlug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- 7. TABELA DE USUÁRIOS E ACESSOS (USERS)
-- ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` VARCHAR(64) NOT NULL,
  `storeId` VARCHAR(64) NOT NULL,
  `nome` VARCHAR(255) NOT NULL,
  `email` VARCHAR(255) NOT NULL,
  `username` VARCHAR(128) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` VARCHAR(32) DEFAULT 'ADMIN',
  `ativo` TINYINT(1) DEFAULT 1,
  `avatar` TEXT,
  `ultimoAcesso` TIMESTAMP NULL DEFAULT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_store` (`storeId`),
  KEY `idx_user_login` (`username`, `email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- DADOS INICIAIS DA LOJA EXEMPLO
-- ----------------------------------------------------------
INSERT INTO `stores` (
  `id`, `slug`, `storeName`, `logo`, `instagram`, `facebook`, `tiktok`,
  `corPrimaria`, `corSecundaria`, `bannerUrl`, `bannerLink`, `bannerTag`,
  `bannerTitulo`, `bannerSubtitulo`, `tituloSite`, `descricaoSite`, `lojaAtiva`,
  `mensagemTopo`, `corBarraTopo`, `email`, `textoDisclosure`, `adminUser`, `adminEmail`, `adminPassword`
) VALUES (
  'store-1',
  'achadinhos-da-maria',
  'Achadinhos da Maria',
  'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=300&auto=format&fit=crop&q=80&fm=webp',
  '@achadinhosdamaria',
  'facebook.com/achadinhosdamaria',
  '@achadinhosdamaria',
  '#2A5C3F',
  '#1B1B1B',
  'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200&auto=format&fit=crop&q=80&fm=webp',
  'Eletrônicos',
  'SELEÇÃO ESPECIAL',
  'Ofertas Imperdíveis do Dia',
  'Achadinhos com até 60% de desconto e cupons exclusivos testados.',
  'Achadinhos da Maria — As Melhores Ofertas e Promoções',
  'Achadinhos imperdíveis da internet, produtos recomendados na Amazon, Shopee, Mercado Livre e Magalu.',
  1,
  '🔥 Frete Grátis e Cupons Exclusivos adicionados hoje! Aproveite antes que acabem.',
  '#2A5C3F',
  'admin@achadinhosdamaria.com.br',
  'Este site participa de programas de afiliados e pode receber comissão pelas compras realizadas nos links, sem custo adicional para você.',
  'admin',
  'admin@achadinhosdamaria.com.br',
  '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.qH0fQY6iKz7j8aR3Fw9rL5q2O.c4M12'
) ON DUPLICATE KEY UPDATE `storeName`=VALUES(`storeName`);

-- ----------------------------------------------------------
-- CATEGORIAS PADRÃO
-- ----------------------------------------------------------
INSERT INTO `categories` (`id`, `storeId`, `nome`, `slug`, `icone`, `ativo`, `ordemMenu`, `exibirNoMenu`) VALUES
('cat-1', 'store-1', 'Eletrônicos & Tech', 'eletronicos', 'Laptop', 1, 1, 1),
('cat-2', 'store-1', 'Casa & Cozinha', 'casa-cozinha', 'Home', 1, 2, 1),
('cat-3', 'store-1', 'Moda & Beleza', 'moda-beleza', 'Sparkles', 1, 3, 1),
('cat-4', 'store-1', 'Livros & Cursos', 'livros-cursos', 'BookOpen', 1, 4, 1),
('cat-5', 'store-1', 'Saúde & Fitness', 'saude-fitness', 'Heart', 1, 5, 1)
ON DUPLICATE KEY UPDATE `nome`=VALUES(`nome`);

-- ----------------------------------------------------------
-- PLATAFORMAS PADRÃO
-- ----------------------------------------------------------
INSERT INTO `platforms` (`id`, `storeId`, `nome`, `slug`, `cor`, `badge`, `icone`, `ativo`, `ordem`) VALUES
('plat-1', 'store-1', 'Amazon', 'amazon', '#FF9900', 'Prime', 'ShoppingBag', 1, 1),
('plat-2', 'store-1', 'Shopee', 'shopee', '#EE4D2D', 'Frete Grátis', 'ShoppingBag', 1, 2),
('plat-3', 'store-1', 'Mercado Livre', 'mercado-livre', '#FFE600', 'Full', 'ShoppingBag', 1, 3),
('plat-4', 'store-1', 'Magalu', 'magalu', '#0086FF', 'Oferta', 'ShoppingBag', 1, 4),
('plat-5', 'store-1', 'Hotmart', 'hotmart', '#F04E23', 'Digital', 'ShoppingBag', 1, 5)
ON DUPLICATE KEY UPDATE `nome`=VALUES(`nome`);

-- ----------------------------------------------------------
-- PRODUTOS PADRÃO (CATÁLOGO INICIAL COMPLETO)
-- ----------------------------------------------------------
INSERT INTO `products` (
  `id`, `storeId`, `ativo`, `tipo`, `plataforma`, `categoria`, `subcategoria`,
  `nome`, `descricao`, `preco`, `precoPromo`, `cupom`, `validade`,
  `linkAfiliado`, `textoBotao`, `video`, `img1`, `img2`, `img3`, `img4`,
  `ordem`, `destaque`
) VALUES
(
  'prod-1', 'store-1', 1, 'FISICO', 'Amazon', 'Eletrônicos & Tech', 'Áudio',
  'Fone de Ouvido Bluetooth JBL Tune 520BT com Som Pure Bass',
  'Fone sem fio JBL Tune 520BT com bateria de até 57 horas de reprodução, carregamento rápido (5 minutos = 3 horas), microfone integrado para chamadas mãos livres e conexão multipontos para alternar entre dispositivos facilmente.',
  299.00, 219.90, 'JBL10OFF', '2027-12-31',
  'https://amazon.com.br?tag=achadinhos-maria-20', 'Ver oferta na Amazon →', '',
  'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&auto=format&fit=crop&q=80&fm=webp',
  'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800&auto=format&fit=crop&q=80&fm=webp',
  'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800&auto=format&fit=crop&q=80&fm=webp', '',
  1, 1
),
(
  'prod-2', 'store-1', 1, 'FISICO', 'Shopee', 'Casa & Cozinha', 'Eletroportáteis',
  'Fritadeira Elétrica Air Fryer Digital 4.5L Inox',
  'Air Fryer com painel touch digital, 8 funções pré-programadas, cesto antiaderente removível com revestimento cerâmico e timer sonoro de 60 minutos. Cozinha alimentos crocantes com até 80% menos óleo.',
  459.90, 289.00, 'AIRFRYER20', '2027-12-31',
  'https://shopee.com.br?affiliate=achadinhos', 'Pegar Desconto na Shopee →', '',
  'https://images.unsplash.com/photo-1585659722983-3a675dabf23d?w=800&auto=format&fit=crop&q=80&fm=webp',
  'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
  2, 1
),
(
  'prod-3', 'store-1', 1, 'FISICO', 'Mercado Livre', 'Eletrônicos & Tech', 'Wearables',
  'Smartwatch Xiaomi Smart Band 8 Tela AMOLED 1.62\"',
  'Pulseira inteligente com mais de 150 modos esportivos, monitoramento contínuo de frequência cardíaca e oxigênio no sangue (SpO2), bateria com autonomia de até 16 dias e resistência à água de 5 ATM (50 metros).',
  249.00, 189.90, 'MELLIBRE15', '2027-12-31',
  'https://mercadolivre.com.br/sec/promo', 'Ver no Mercado Livre →', '',
  'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=800&auto=format&fit=crop&q=80&fm=webp',
  'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
  3, 1
),
(
  'prod-4', 'store-1', 1, 'FISICO', 'Amazon', 'Casa & Cozinha', 'Organização',
  'Kit 6 Potes Herméticos de Vidro com Tampa de Bambu',
  'Conjunto com 6 potes de vidro borossilicato resistente a calor e choque térmico com tampas herméticas em bambu natural e anel de silicone. Ideais para mantimentos, grãos, café e organização estética de despensa.',
  169.90, 119.00, 'CASA10', '2027-12-31',
  'https://amazon.com.br?tag=achadinhos-maria-20', 'Ver oferta na Amazon →', '',
  'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=800&auto=format&fit=crop&q=80&fm=webp',
  'https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80&fm=webp', '', '',
  4, 0
),
(
  'prod-5', 'store-1', 1, 'FISICO', 'Magalu', 'Moda & Beleza', 'Cabelos',
  'Escova Secadora e Modeladora 3 em 1 Cerâmica Íons 1200W',
  'Seca, alisa e modela com cerdas macias anti-frizz e tecnologia de íons negativos que selam as cutículas dos fios. Possui 3 temperaturas ajustáveis e cabo giratório 360 graus.',
  189.90, 99.90, 'BELEZA25', '2027-12-31',
  'https://magazineluiza.com.br', 'Ver na Magalu →', '',
  'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=800&auto=format&fit=crop&q=80&fm=webp',
  '', '', '',
  5, 0
),
(
  'prod-6', 'store-1', 1, 'DIGITAL', 'Hotmart', 'Livros & Cursos', 'Desenvolvimento',
  'Curso Completo de Marketing para Afiliados e Tráfego Pago',
  'Aprenda do zero ao avançado como criar campanhas de alto retorno, encontrar produtos vencedores e estruturar uma renda recorrente com programas de afiliados globais.',
  497.00, 197.00, 'DESCONTOVIP', '2027-12-31',
  'https://hotmart.com', 'Quero Conhecer o Curso →', '',
  'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=800&auto=format&fit=crop&q=80&fm=webp',
  '', '', '',
  6, 0
),
(
  'prod-7', 'store-1', 1, 'FISICO', 'Shopee', 'Eletrônicos & Tech', 'Acessórios',
  'Luminária de Mesa LED Articulada Recarregável Touch com Porta-Caneta',
  'Lâmpada de mesa com 3 intensidades de luz (quente, fria e neutra), haste flexível de silicone, suporte para celular integrado e bateria recarregável USB com até 8h de duração contínua.',
  69.90, 38.50, '', '2027-12-31',
  'https://shopee.com.br', 'Ver Oferta na Shopee →', '',
  'https://images.unsplash.com/photo-1534353436294-0dbd4bdac845?w=800&auto=format&fit=crop&q=80&fm=webp',
  '', '', '',
  7, 0
),
(
  'prod-8', 'store-1', 1, 'FISICO', 'Amazon', 'Eletrônicos & Tech', 'Dispositivos',
  'Echo Pop Smart Speaker Compacto com Alexa e Som Envolvente',
  'A smart speaker com som surround compacto que cabe perfeitamente em quartos e espaços pequenos. Peça músicas para Alexa, controle dispositivos de casa inteligente, timer, previsão do tempo e muito mais.',
  349.00, 249.00, 'ALEXAPROMO', '2027-12-31',
  'https://amazon.com.br', 'Ver na Amazon →', '',
  'https://images.unsplash.com/photo-1543512214-318c7553f230?w=800&auto=format&fit=crop&q=80&fm=webp',
  '', '', '',
  8, 0
)
ON DUPLICATE KEY UPDATE `nome`=VALUES(`nome`), `preco`=VALUES(`preco`), `precoPromo`=VALUES(`precoPromo`);

-- ----------------------------------------------------------
-- USUÁRIO ADMINISTRADOR PADRÃO
-- ----------------------------------------------------------
INSERT INTO `users` (
  `id`, `storeId`, `nome`, `email`, `username`, `password`, `role`, `ativo`
) VALUES (
  'user-admin-1', 'store-1', 'Administrador Principal', 'admin@achadinhosdamaria.com.br', 'admin', '$2a$10$vI8aWBnW3fID.ZQ4/zo1G.qH0fQY6iKz7j8aR3Fw9rL5q2O.c4M12', 'ADMIN', 1
) ON DUPLICATE KEY UPDATE `nome`=VALUES(`nome`);

SET FOREIGN_KEY_CHECKS = 1;
