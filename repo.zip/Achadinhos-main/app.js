/**
 * Planiloja Achadinhos - Hostinger Startup File (app.js)
 */
import './server.js';
